export const BUTTON_GROUP = {
	LEFT: 'left',
	RIGHT: 'right',
};
