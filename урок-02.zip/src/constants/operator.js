export const OPERATOR = {
	PLUS: '+',
	MINUS: '-',
	NONE: '',
};
