export const COMMAND = {
	RESET: 'C',
	RESULT: '=',
};
